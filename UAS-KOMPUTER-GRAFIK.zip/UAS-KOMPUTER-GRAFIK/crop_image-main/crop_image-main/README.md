# uas_komputer_grafik

Uas Komputer Grafik Semester-6
Nama : Muhammad Ululazmi
NIM : 201011400362
Kelas : 06TPLE006